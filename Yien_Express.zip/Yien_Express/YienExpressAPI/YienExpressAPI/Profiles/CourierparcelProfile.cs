﻿using AutoMapper;
using YienExpressAPI.DTO;
using YienExpressAPI.Model;

namespace YienExpressAPI.Profiles
{
    public class CourierparcelProfile:Profile
    {
        public CourierparcelProfile()
        {
            CreateMap<Courierparcel, CourierparcelReadDTO>();
            CreateMap<CourierparcelCreateDTO, Courierparcel>();

        }
    }
}
