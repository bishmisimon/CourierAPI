﻿using AutoMapper;
using YienExpressAPI.DTO;
using YienExpressAPI.Model;

namespace YienExpressAPI.Profiles
{
    public class PersonalcustomerProfile:Profile
    {

        public PersonalcustomerProfile() 
        {
            CreateMap<PersonalcustomerCreateDTO, Personalcustomer>();
            CreateMap<Personalcustomer, PersonalcustomerReadDTO>();
           

        }
        
    }
}
