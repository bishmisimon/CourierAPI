﻿using AutoMapper;
using YienExpressAPI.DTO;
using YienExpressAPI.Model;

namespace YienExpressAPI.Profiles
{
    public class CoparatecustomerProfile:Profile
    {
        public CoparatecustomerProfile()
        {
            CreateMap<Coparatecustomer, CoparatecustomerReadDTO>();
            CreateMap<CoparatecustomerCreateDTO, Coparatecustomer>();
        }
    }
}
