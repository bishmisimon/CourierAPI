﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using YienExpressAPI.Data;
using YienExpressAPI.DTO;
using YienExpressAPI.Model;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace YienExpressAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourierparcelsController : ControllerBase
    {
        public ICourierparcelRepo CourierparcelRepo;
        public IMapper mapper;


        public CourierparcelsController(ICourierparcelRepo tRepo, IMapper tMapper)
        {
            CourierparcelRepo = tRepo;
            mapper = tMapper;
        }



        [HttpGet]
        public ActionResult<IEnumerable<CourierparcelReadDTO>> GetCourierparcels()
        {
            var courierparcels = CourierparcelRepo.GetCourierparcels();
            return Ok(mapper.Map<IEnumerable<CourierparcelReadDTO>>(courierparcels));
        }
        [HttpGet("{code}", Name = "GetCourierparcel")]
        public ActionResult<CourierparcelReadDTO> GetCourierparcel(int code)
        {
            var courierparcel = CourierparcelRepo.GetCourierparcel(code);
            if (courierparcel != null)
                return Ok(mapper.Map<CourierparcelReadDTO>(courierparcel));
            else
                return NotFound();

        }





        [HttpPost]

        public ActionResult<CourierparcelCreateDTO> CreateCourierparcel(CourierparcelCreateDTO courierparcel)
        {
            var modelCourierparcel = mapper.Map<Courierparcel>(courierparcel);
            CourierparcelRepo.CreateCourierparcel(modelCourierparcel);
            CourierparcelRepo.Save();
            var newCourierparcel = mapper.Map<CourierparcelReadDTO>(modelCourierparcel);
            return CreatedAtRoute(nameof(GetCourierparcel),
                new { code = newCourierparcel.ID }, newCourierparcel);
        }





        [HttpPut("{code}")]

        public ActionResult Update(int code, CourierparcelCreateDTO courierparcel)
        {
            var courierparcelToUpdate = mapper.Map<Courierparcel>(courierparcel);
            courierparcelToUpdate.ID = code;
            if (CourierparcelRepo.Update(courierparcelToUpdate))
                return Ok();
            else
                return NotFound();
        }


        [HttpDelete("{code}")]

        public ActionResult Delete(int code)
        {
            var courierparcelToDelete = CourierparcelRepo.GetCourierparcel(code);

            if (courierparcelToDelete != null)
            {
                CourierparcelRepo.Delete(courierparcelToDelete);
                return Ok();
            }
            else
                return NotFound();
        }

    }
}
