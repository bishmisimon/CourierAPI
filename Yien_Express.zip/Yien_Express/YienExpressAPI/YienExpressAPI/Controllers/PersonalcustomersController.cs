﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using YienExpressAPI.Data;
using YienExpressAPI.DTO;
using YienExpressAPI.Model;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace YienExpressAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonalcustomersController : ControllerBase
    {
        public IPersonalcustomerRepo PersonalcustomerRepo;
        public IMapper mapper;

        public PersonalcustomersController(IPersonalcustomerRepo pRepo, IMapper pMapper) {

            
           PersonalcustomerRepo=pRepo;
            mapper=pMapper;
        
        }





        [HttpGet]
        public ActionResult<IEnumerable<PersonalcustomerReadDTO>> GetPersonalcustomers()
        {
            var personalcustomers = PersonalcustomerRepo.GetPersonalcustomers();
            return Ok(mapper.Map<IEnumerable<PersonalcustomerReadDTO>>(personalcustomers));
        }
        [HttpGet("{code}", Name = "GetPersonalcustomer")]
        public ActionResult<PersonalcustomerReadDTO> GetPersonalcustomer(int code)
        {
            var personalcustomer = PersonalcustomerRepo.GetPersonalcustomer(code);
            if (personalcustomer != null)
                return Ok(mapper.Map<PersonalcustomerReadDTO>(personalcustomer));
            else
                return NotFound();

        }



        // POST api/<PersonalcustomersController>


        [HttpPost]

        public ActionResult<PersonalcustomerCreateDTO> CreatePersonalcustomer(PersonalcustomerCreateDTO personalcustomer)
        {
            var modelPersonalcustomer = mapper.Map<Personalcustomer>(personalcustomer);
            PersonalcustomerRepo.CreatePersonalcustomer(modelPersonalcustomer);
            PersonalcustomerRepo.Save();
            var newPersonalcustomer = mapper.Map<PersonalcustomerReadDTO>(modelPersonalcustomer);
            return CreatedAtRoute(nameof(GetPersonalcustomer),
                new { code = newPersonalcustomer.ID }, newPersonalcustomer);
        }



        [HttpPut("{code}")]

        public ActionResult Update(int code, PersonalcustomerCreateDTO personalcustomer)
        {
            var personalcustomerToUpdate = mapper.Map<Personalcustomer>(personalcustomer);
            personalcustomerToUpdate.ID = code;
            if (PersonalcustomerRepo.Update(personalcustomerToUpdate))
                return Ok();
            else
                return NotFound();
        }

        // DELETE api/<PersonalcustomersController>/5
        [HttpDelete("{code}")]

        public ActionResult Delete(int code)
        {
            var personalcustomerToDelete = PersonalcustomerRepo.GetPersonalcustomer(code);

            if (personalcustomerToDelete != null)
            {
                PersonalcustomerRepo.Delete(personalcustomerToDelete);
                return Ok();
            }
            else
                return NotFound();
        }
    }
}
