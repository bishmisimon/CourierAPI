﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using YienExpressAPI.Data;
using YienExpressAPI.DTO;
using YienExpressAPI.Model;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace YienExpressAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CoparatecustomersController : ControllerBase
    {

        public ICoparatecustomerRepo CoparatecustomerRepo;
        public IMapper mapper;


        public CoparatecustomersController(ICoparatecustomerRepo cRepo, IMapper cMapper)
        {
            CoparatecustomerRepo = cRepo;
            mapper = cMapper;
        }

        [HttpGet]
        public ActionResult<IEnumerable<CoparatecustomerReadDTO>> GetCustomer()
        {
            var coparatecustomers = CoparatecustomerRepo.GetCoparatecustomers();
            return Ok(mapper.Map<IEnumerable<CoparatecustomerReadDTO>>(coparatecustomers));
        }
        [HttpGet("{code}", Name = "GetCoparatecustomer")]
        public ActionResult<CoparatecustomerReadDTO> GetCoparatecustomer(int code)
        {
            var coparatecustomer = CoparatecustomerRepo.GetCoparatecustomer(code);
            if (coparatecustomer != null)
                return Ok(mapper.Map<CoparatecustomerReadDTO>(coparatecustomer));
            else
                return NotFound();

        }




        // POST api/<CoparatecustomersController>
        [HttpPost]

        public ActionResult<CoparatecustomerCreateDTO> CreateCoparatecustomer(CoparatecustomerCreateDTO coparatecustomer)
        {
            var modelCoparatecustomer = mapper.Map<Coparatecustomer>(coparatecustomer);
            CoparatecustomerRepo.CreateCoparatecustomer(modelCoparatecustomer);
            CoparatecustomerRepo.Save();
            var newCoparatecustomer = mapper.Map<CoparatecustomerReadDTO>(modelCoparatecustomer);
            return CreatedAtRoute(nameof(GetCoparatecustomer),
                new { code = newCoparatecustomer.ID }, newCoparatecustomer);
        }


        [HttpPut("{code}")]

        public ActionResult Update(int code, CoparatecustomerCreateDTO coparatecustomer)
        {
            var coparatecustomerToUpdate = mapper.Map<Coparatecustomer>(coparatecustomer);
            coparatecustomerToUpdate.ID = code;
            if (CoparatecustomerRepo.Update(coparatecustomerToUpdate))
                return Ok();
            else
                return NotFound();
        }

        // DELETE api/<CoparatecustomersController>/5
        [HttpDelete("{code}")]

        public ActionResult Delete(int code)
        {
            var coparatecustomerToDelete = CoparatecustomerRepo.GetCoparatecustomer(code);

            if (coparatecustomerToDelete != null)
            {
                CoparatecustomerRepo.Delete(coparatecustomerToDelete);
                return Ok();
            }
            else
                return NotFound();
        }
    }
}
