﻿using YienExpressAPI.Model;

namespace YienExpressAPI.Data
{
    public interface ICourierparcelRepo
    {
        void CreateCourierparcel(Courierparcel courierparcel);
        void Delete(Courierparcel courierparcel);
        bool Update(Courierparcel courierparcel);
        Courierparcel GetCourierparcel(int id);
        IEnumerable<Courierparcel> GetCourierparcels();

        bool Save();
    }
}
