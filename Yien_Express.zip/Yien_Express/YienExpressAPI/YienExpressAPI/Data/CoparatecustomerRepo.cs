﻿using YienExpressAPI.Model;

namespace YienExpressAPI.Data
{
    public class CoparatecustomerRepo : ICoparatecustomerRepo
    {

        private AppDBContext context;

        public CoparatecustomerRepo(AppDBContext dBContext)
        {
            context = dBContext;
        }
        public void CreateCoparatecustomer(Coparatecustomer coparatecustomer)
        {
            if (coparatecustomer == null)
                throw new ArgumentNullException(nameof(coparatecustomer));
            context.Coparatecustomers.Add(coparatecustomer);
        }

        public void Delete(Coparatecustomer coparatecustomer)
        {
            context.Coparatecustomers.Remove(coparatecustomer);
            Save();
        }

        public Coparatecustomer GetCoparatecustomer(int id)
        {
            return context.Coparatecustomers.FirstOrDefault(c => c.ID == id);
        }

        public IEnumerable<Coparatecustomer> GetCoparatecustomers()
        {
            return context.Coparatecustomers.ToList();
        }
        
        public bool Save()
        {
            int count = context.SaveChanges();
            if (count > 0)
                return true;
            else
                return false;
        }

        public bool Update(Coparatecustomer coparatecustomer)
        {
            context.Coparatecustomers.Update(coparatecustomer);
            return Save();
        }
    }
}
