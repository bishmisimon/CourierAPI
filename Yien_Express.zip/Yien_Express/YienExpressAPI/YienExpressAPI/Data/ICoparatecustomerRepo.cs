﻿using YienExpressAPI.Model;

namespace YienExpressAPI.Data
{
    public interface ICoparatecustomerRepo
    {
        void CreateCoparatecustomer(Coparatecustomer coparatecustomer);
        void Delete(Coparatecustomer coparatecustomer);
        bool Update(Coparatecustomer coparatecustomer);
        Coparatecustomer GetCoparatecustomer(int id);
        IEnumerable<Coparatecustomer> GetCoparatecustomers();

        bool Save();
    }
}
