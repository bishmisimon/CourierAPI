﻿using YienExpressAPI.Data;
using YienExpressAPI.Model;

namespace YienExpressAPI.Data
{
    public class CourierparcelRepo : ICourierparcelRepo
    {

        private AppDBContext context;

        public CourierparcelRepo(AppDBContext dBContext)
        {
            context = dBContext;
        }
        public void CreateCourierparcel(Courierparcel courierparcel)
        {
            if (courierparcel== null)
                throw new ArgumentNullException(nameof(courierparcel));
            context.Courierparcels.Add(courierparcel);
        }

        public void Delete(Courierparcel courierparcel)
        {
            context.Courierparcels.Remove(courierparcel);
            Save();
        }

        public Courierparcel GetCourierparcel(int id)
        {
            return context.Courierparcels.FirstOrDefault(u => u.ID == id);
        }

        public IEnumerable<Courierparcel> GetCourierparcels()
        {
            return context.Courierparcels.ToList();
        }

        public bool Save()
        {
            int count = context.SaveChanges();
            if (count > 0)
                return true;
            else
                return false;
        }

        public bool Update(Courierparcel courierparcel)
        {
            context.Courierparcels.Update(courierparcel);
            return Save();
        }
    }
}
