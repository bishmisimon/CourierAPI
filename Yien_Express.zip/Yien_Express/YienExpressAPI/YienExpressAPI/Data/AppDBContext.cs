﻿
using Microsoft.EntityFrameworkCore;

using YienExpressAPI.Model;


namespace YienExpressAPI.Data

{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options)
        {

        }
        public DbSet<Courierparcel> Courierparcels { get; set; }

        public DbSet<Coparatecustomer> Coparatecustomers { get; set; }

        public DbSet<Personalcustomer> Personalcustomers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Courierparcel>().
                Property(u => u.Delivery_charge).HasColumnType("decimal(18,2)");
            modelBuilder.Entity<Courierparcel>().
                Property(p => p.Collecting_Amount).HasColumnType("decimal(18,2)");



        }

       





        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var connection = "Data Source=LAPTOP-BISHMI;Initial Catalog=YienAPI;Integrated Security=True;Persist Security Info=True;TrustServerCertificate=True";
            optionsBuilder.UseSqlServer(connection);

        }
    }
}
