﻿using YienExpressAPI.Data;
using YienExpressAPI.Model;

namespace YienExpressAPI.Data
{
    public class PersonalcustomerRepo : IPersonalcustomerRepo
    {

        private AppDBContext context;

        public PersonalcustomerRepo(AppDBContext dBContext)
        {
            context = dBContext;
        }
        public void CreatePersonalcustomer(Personalcustomer personalcustomer)
        {
            if (personalcustomer == null)
                throw new ArgumentNullException(nameof(personalcustomer));
            context.Personalcustomers.Add(personalcustomer);
        }

        public void Delete(Personalcustomer personalcustomer)
        {

            context.Personalcustomers.Remove(personalcustomer);
            Save();
        }

        public Personalcustomer GetPersonalcustomer(int id)
        {
            return context.Personalcustomers.FirstOrDefault(p => p.ID == id);
        }

        public IEnumerable<Personalcustomer> GetPersonalcustomers()
        {
            return context.Personalcustomers.ToList();
        }

        public bool Save()
        {
            int count = context.SaveChanges();
            if (count > 0)
                return true;
            else
                return false;
        }

        public bool Update(Personalcustomer personalcustomer)
        {
            context.Personalcustomers.Update(personalcustomer);
            return Save();
        }
    }
}
