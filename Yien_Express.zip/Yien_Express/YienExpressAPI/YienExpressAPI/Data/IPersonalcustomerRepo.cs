﻿using YienExpressAPI.Model;

namespace YienExpressAPI.Data
{
    public interface IPersonalcustomerRepo
    {
        void CreatePersonalcustomer(Personalcustomer personalcustomer);
        void Delete(Personalcustomer personalcustomer);
        bool Update(Personalcustomer personalcustomer);
        Personalcustomer GetPersonalcustomer(int id);
        IEnumerable<Personalcustomer> GetPersonalcustomers();

        bool Save();
    }
}
