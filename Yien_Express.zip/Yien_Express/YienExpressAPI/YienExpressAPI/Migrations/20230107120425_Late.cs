﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace YienExpressAPI.Migrations
{
    /// <inheritdoc />
    public partial class Late : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Coparatecustomers",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CompanyName = table.Column<string>(name: "Company_Name", type: "nvarchar(max)", nullable: false),
                    CompanyAddress = table.Column<string>(name: "Company_Address", type: "nvarchar(max)", nullable: true),
                    Phone = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AlternativePhone = table.Column<string>(name: "Alternative_Phone", type: "nvarchar(max)", nullable: true),
                    BuinessEmail = table.Column<string>(name: "Buiness_Email", type: "nvarchar(max)", nullable: true),
                    PackagePlan = table.Column<string>(name: "Package_Plan", type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Coparatecustomers", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Courierparcels",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NoofItems = table.Column<int>(name: "No_of_Items", type: "int", nullable: false),
                    Weight = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DeliverStatus = table.Column<string>(name: "Deliver_Status", type: "nvarchar(max)", nullable: true),
                    SendingDate = table.Column<DateTime>(name: "Sending_Date", type: "datetime2", nullable: false),
                    ToDeliverBranch = table.Column<string>(name: "ToDeliver_Branch", type: "nvarchar(max)", nullable: true),
                    DeliveredDate = table.Column<DateTime>(name: "Delivered_Date", type: "datetime2", nullable: false),
                    Paymenttype = table.Column<string>(name: "Payment_type", type: "nvarchar(max)", nullable: true),
                    Deliverycharge = table.Column<decimal>(name: "Delivery_charge", type: "decimal(18,2)", nullable: false),
                    CollectingAmount = table.Column<decimal>(name: "Collecting_Amount", type: "decimal(18,2)", nullable: false),
                    VechicleType = table.Column<string>(name: "Vechicle_Type", type: "nvarchar(max)", nullable: true),
                    ReceiverDetails = table.Column<string>(name: "Receiver_Details", type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Courierparcels", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Personalcustomers",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PEmail = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PAddress = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PCity = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PProvince = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PPostalCode = table.Column<string>(name: "PPostal_Code", type: "nvarchar(max)", nullable: true),
                    PCountry = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PPhone = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Personalcustomers", x => x.ID);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Coparatecustomers");

            migrationBuilder.DropTable(
                name: "Courierparcels");

            migrationBuilder.DropTable(
                name: "Personalcustomers");
        }
    }
}
