﻿using System.ComponentModel.DataAnnotations;

namespace YienExpressAPI.Model
{
    public class Personalcustomer
    {
        [Key]
        [Required]
        public int ID { get; set; }
        [Required]
        public string? Name { get; set; }

        public string? PEmail { get; set; }
        public string? PAddress { get; set; }
        public string? PCity { get; set; }
        public string? PProvince { get; set; }
        public string? PPostal_Code { get; set; }
        public string? PCountry { get; set; }
        public string? PPhone { get; set; }
    }
}
