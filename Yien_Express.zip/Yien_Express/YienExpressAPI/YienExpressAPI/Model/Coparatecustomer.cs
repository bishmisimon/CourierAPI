﻿using System.ComponentModel.DataAnnotations;

namespace YienExpressAPI.Model
{
    public class Coparatecustomer
    {


        [Key]
        [Required]
        public int ID { get; set; }

        [Required]
        public string? Company_Name { get; set; }
        public string? Company_Address { get; set; }
        public string? Phone { get; set; }

        public string? Alternative_Phone { get; set; }

        public string? Buiness_Email { get; set; }

        public string? Package_Plan { get; set; }
    }
}
