﻿using System.ComponentModel.DataAnnotations;

namespace YienExpressAPI.DTO
{
    public class CourierparcelCreateDTO
    {
        
        [Required]
        
        
        public int No_of_Items { get; set; }

        [Required]
        public string? Weight { get; set; }

        public string? Deliver_Status { get; set; }

        public string?Sending_Date { get; set; }

        public string? ToDeliver_Branch { get; set; }

       


        public string? Delivered_Date { get; set; }

        public string? Payment_type { get; set; }

        public decimal Delivery_charge { get; set; }

        public decimal Collecting_Amount { get; set; }
        public string? Vechicle_Type { get; set; }
        public string? Receiver_Details { get; set; }


    }
}
