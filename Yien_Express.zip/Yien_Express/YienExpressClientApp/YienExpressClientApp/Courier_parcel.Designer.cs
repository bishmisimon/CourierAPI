﻿namespace YienExpressClientApp
{
    partial class Courier_parcel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Courier_parcel));
            this.lblID = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lbDelivered_Date = new System.Windows.Forms.Label();
            this.lblSendingDate = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.dgvCourierParcels = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dtpDeliveredDate = new System.Windows.Forms.DateTimePicker();
            this.dtpSendingDate = new System.Windows.Forms.DateTimePicker();
            this.txtDeliver_Branch = new System.Windows.Forms.TextBox();
            this.lblDeliver_Branch = new System.Windows.Forms.Label();
            this.txtDeliver_Status = new System.Windows.Forms.TextBox();
            this.lblDeliver_Status = new System.Windows.Forms.Label();
            this.txtWeight = new System.Windows.Forms.TextBox();
            this.lblWeight = new System.Windows.Forms.Label();
            this.txtNo_Of_Items = new System.Windows.Forms.TextBox();
            this.lblNo_Of_Items = new System.Windows.Forms.Label();
            this.lblPayment_Type = new System.Windows.Forms.Label();
            this.txtPayment_Type = new System.Windows.Forms.TextBox();
            this.lblCollectingAmount = new System.Windows.Forms.Label();
            this.txtDelivery_Charge = new System.Windows.Forms.TextBox();
            this.txtCollecting_Amount = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbVechicle = new System.Windows.Forms.ComboBox();
            this.txtReceiver = new System.Windows.Forms.TextBox();
            this.lblDelivery_Charge = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnHome = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCourierParcels)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(46, 10);
            this.lblID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(0, 28);
            this.lblID.TabIndex = 50;
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.Orange;
            this.btnUpdate.Font = new System.Drawing.Font("Segoe UI Semibold", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnUpdate.Location = new System.Drawing.Point(1217, 512);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(119, 54);
            this.btnUpdate.TabIndex = 48;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Orange;
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI Semibold", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnAdd.Location = new System.Drawing.Point(1217, 445);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(122, 59);
            this.btnAdd.TabIndex = 47;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lbDelivered_Date
            // 
            this.lbDelivered_Date.AutoSize = true;
            this.lbDelivered_Date.Location = new System.Drawing.Point(36, 508);
            this.lbDelivered_Date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbDelivered_Date.Name = "lbDelivered_Date";
            this.lbDelivered_Date.Size = new System.Drawing.Size(136, 28);
            this.lbDelivered_Date.TabIndex = 46;
            this.lbDelivered_Date.Text = "Delivery_Date";
            // 
            // lblSendingDate
            // 
            this.lblSendingDate.AutoSize = true;
            this.lblSendingDate.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSendingDate.Location = new System.Drawing.Point(36, 243);
            this.lblSendingDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSendingDate.Name = "lblSendingDate";
            this.lblSendingDate.Size = new System.Drawing.Size(135, 28);
            this.lblSendingDate.TabIndex = 45;
            this.lblSendingDate.Text = "Sending Date";
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Orange;
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI Semibold", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnDelete.Location = new System.Drawing.Point(1217, 572);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(119, 53);
            this.btnDelete.TabIndex = 49;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // dgvCourierParcels
            // 
            this.dgvCourierParcels.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dgvCourierParcels.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCourierParcels.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1});
            this.dgvCourierParcels.Location = new System.Drawing.Point(425, 48);
            this.dgvCourierParcels.Margin = new System.Windows.Forms.Padding(4);
            this.dgvCourierParcels.Name = "dgvCourierParcels";
            this.dgvCourierParcels.RowHeadersWidth = 51;
            this.dgvCourierParcels.RowTemplate.Height = 29;
            this.dgvCourierParcels.Size = new System.Drawing.Size(731, 379);
            this.dgvCourierParcels.TabIndex = 44;
            this.dgvCourierParcels.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCourierParcels_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Edit";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.Width = 125;
            // 
            // dtpDeliveredDate
            // 
            this.dtpDeliveredDate.AccessibleRole = System.Windows.Forms.AccessibleRole.Grip;
            this.dtpDeliveredDate.Location = new System.Drawing.Point(36, 541);
            this.dtpDeliveredDate.Margin = new System.Windows.Forms.Padding(4);
            this.dtpDeliveredDate.Name = "dtpDeliveredDate";
            this.dtpDeliveredDate.Size = new System.Drawing.Size(343, 34);
            this.dtpDeliveredDate.TabIndex = 43;
            // 
            // dtpSendingDate
            // 
            this.dtpSendingDate.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dtpSendingDate.Location = new System.Drawing.Point(36, 290);
            this.dtpSendingDate.Margin = new System.Windows.Forms.Padding(4);
            this.dtpSendingDate.Name = "dtpSendingDate";
            this.dtpSendingDate.Size = new System.Drawing.Size(343, 34);
            this.dtpSendingDate.TabIndex = 42;
            // 
            // txtDeliver_Branch
            // 
            this.txtDeliver_Branch.Location = new System.Drawing.Point(36, 374);
            this.txtDeliver_Branch.Margin = new System.Windows.Forms.Padding(4);
            this.txtDeliver_Branch.Name = "txtDeliver_Branch";
            this.txtDeliver_Branch.Size = new System.Drawing.Size(350, 34);
            this.txtDeliver_Branch.TabIndex = 41;
            // 
            // lblDeliver_Branch
            // 
            this.lblDeliver_Branch.AutoSize = true;
            this.lblDeliver_Branch.Location = new System.Drawing.Point(36, 342);
            this.lblDeliver_Branch.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDeliver_Branch.Name = "lblDeliver_Branch";
            this.lblDeliver_Branch.Size = new System.Drawing.Size(145, 28);
            this.lblDeliver_Branch.TabIndex = 40;
            this.lblDeliver_Branch.Text = "Deliver_Branch";
            // 
            // txtDeliver_Status
            // 
            this.txtDeliver_Status.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtDeliver_Status.Location = new System.Drawing.Point(38, 192);
            this.txtDeliver_Status.Margin = new System.Windows.Forms.Padding(4);
            this.txtDeliver_Status.Name = "txtDeliver_Status";
            this.txtDeliver_Status.Size = new System.Drawing.Size(350, 34);
            this.txtDeliver_Status.TabIndex = 39;
            // 
            // lblDeliver_Status
            // 
            this.lblDeliver_Status.AutoSize = true;
            this.lblDeliver_Status.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDeliver_Status.Location = new System.Drawing.Point(44, 147);
            this.lblDeliver_Status.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDeliver_Status.Name = "lblDeliver_Status";
            this.lblDeliver_Status.Size = new System.Drawing.Size(138, 28);
            this.lblDeliver_Status.TabIndex = 38;
            this.lblDeliver_Status.Text = "Deliver_Status";
            // 
            // txtWeight
            // 
            this.txtWeight.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtWeight.Location = new System.Drawing.Point(235, 81);
            this.txtWeight.Margin = new System.Windows.Forms.Padding(4);
            this.txtWeight.Multiline = true;
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Size = new System.Drawing.Size(139, 43);
            this.txtWeight.TabIndex = 37;
            this.txtWeight.TextChanged += new System.EventHandler(this.txtWeight_TextChanged);
            // 
            // lblWeight
            // 
            this.lblWeight.AutoSize = true;
            this.lblWeight.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblWeight.Location = new System.Drawing.Point(235, 48);
            this.lblWeight.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWeight.Name = "lblWeight";
            this.lblWeight.Size = new System.Drawing.Size(161, 28);
            this.lblWeight.TabIndex = 36;
            this.lblWeight.Text = "Weight of Parcel";
            // 
            // txtNo_Of_Items
            // 
            this.txtNo_Of_Items.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtNo_Of_Items.Location = new System.Drawing.Point(46, 81);
            this.txtNo_Of_Items.Margin = new System.Windows.Forms.Padding(4);
            this.txtNo_Of_Items.Multiline = true;
            this.txtNo_Of_Items.Name = "txtNo_Of_Items";
            this.txtNo_Of_Items.Size = new System.Drawing.Size(133, 41);
            this.txtNo_Of_Items.TabIndex = 35;
            // 
            // lblNo_Of_Items
            // 
            this.lblNo_Of_Items.AutoSize = true;
            this.lblNo_Of_Items.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNo_Of_Items.Location = new System.Drawing.Point(46, 48);
            this.lblNo_Of_Items.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNo_Of_Items.Name = "lblNo_Of_Items";
            this.lblNo_Of_Items.Size = new System.Drawing.Size(121, 28);
            this.lblNo_Of_Items.TabIndex = 34;
            this.lblNo_Of_Items.Text = "No of Items";
            // 
            // lblPayment_Type
            // 
            this.lblPayment_Type.AutoSize = true;
            this.lblPayment_Type.Location = new System.Drawing.Point(38, 597);
            this.lblPayment_Type.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPayment_Type.Name = "lblPayment_Type";
            this.lblPayment_Type.Size = new System.Drawing.Size(140, 28);
            this.lblPayment_Type.TabIndex = 53;
            this.lblPayment_Type.Text = "Payment Type";
            // 
            // txtPayment_Type
            // 
            this.txtPayment_Type.Location = new System.Drawing.Point(36, 629);
            this.txtPayment_Type.Margin = new System.Windows.Forms.Padding(4);
            this.txtPayment_Type.Name = "txtPayment_Type";
            this.txtPayment_Type.Size = new System.Drawing.Size(350, 34);
            this.txtPayment_Type.TabIndex = 54;
            // 
            // lblCollectingAmount
            // 
            this.lblCollectingAmount.AutoSize = true;
            this.lblCollectingAmount.Location = new System.Drawing.Point(452, 586);
            this.lblCollectingAmount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCollectingAmount.Name = "lblCollectingAmount";
            this.lblCollectingAmount.Size = new System.Drawing.Size(184, 28);
            this.lblCollectingAmount.TabIndex = 56;
            this.lblCollectingAmount.Text = "Collecting_Amount";
            // 
            // txtDelivery_Charge
            // 
            this.txtDelivery_Charge.Location = new System.Drawing.Point(452, 522);
            this.txtDelivery_Charge.Margin = new System.Windows.Forms.Padding(4);
            this.txtDelivery_Charge.Multiline = true;
            this.txtDelivery_Charge.Name = "txtDelivery_Charge";
            this.txtDelivery_Charge.Size = new System.Drawing.Size(240, 43);
            this.txtDelivery_Charge.TabIndex = 57;
            // 
            // txtCollecting_Amount
            // 
            this.txtCollecting_Amount.Location = new System.Drawing.Point(452, 620);
            this.txtCollecting_Amount.Margin = new System.Windows.Forms.Padding(4);
            this.txtCollecting_Amount.Multiline = true;
            this.txtCollecting_Amount.Name = "txtCollecting_Amount";
            this.txtCollecting_Amount.Size = new System.Drawing.Size(240, 43);
            this.txtCollecting_Amount.TabIndex = 58;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 424);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 28);
            this.label1.TabIndex = 59;
            this.label1.Text = "Vechicle Type";
            // 
            // cmbVechicle
            // 
            this.cmbVechicle.FormattingEnabled = true;
            this.cmbVechicle.Items.AddRange(new object[] {
            "Bike",
            "Van",
            "Lorry"});
            this.cmbVechicle.Location = new System.Drawing.Point(44, 468);
            this.cmbVechicle.Name = "cmbVechicle";
            this.cmbVechicle.Size = new System.Drawing.Size(120, 36);
            this.cmbVechicle.TabIndex = 60;
            this.cmbVechicle.Text = "Bike";
            // 
            // txtReceiver
            // 
            this.txtReceiver.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtReceiver.Location = new System.Drawing.Point(760, 489);
            this.txtReceiver.Margin = new System.Windows.Forms.Padding(4);
            this.txtReceiver.Multiline = true;
            this.txtReceiver.Name = "txtReceiver";
            this.txtReceiver.Size = new System.Drawing.Size(431, 174);
            this.txtReceiver.TabIndex = 62;
            // 
            // lblDelivery_Charge
            // 
            this.lblDelivery_Charge.AutoSize = true;
            this.lblDelivery_Charge.Location = new System.Drawing.Point(452, 445);
            this.lblDelivery_Charge.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDelivery_Charge.Name = "lblDelivery_Charge";
            this.lblDelivery_Charge.Size = new System.Drawing.Size(158, 28);
            this.lblDelivery_Charge.TabIndex = 55;
            this.lblDelivery_Charge.Text = "Delivery_Charge";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(829, 445);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(250, 28);
            this.label2.TabIndex = 63;
            this.label2.Text = "Receiver\'s Address & Phone";
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.Color.Orange;
            this.btnHome.Font = new System.Drawing.Font("Segoe UI Semibold", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnHome.Location = new System.Drawing.Point(1217, 633);
            this.btnHome.Margin = new System.Windows.Forms.Padding(4);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(119, 53);
            this.btnHome.TabIndex = 64;
            this.btnHome.Text = "Home";
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click_1);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1177, 123);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(188, 215);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 66;
            this.pictureBox2.TabStop = false;
            // 
            // Courier_parcel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.ClientSize = new System.Drawing.Size(1377, 698);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtReceiver);
            this.Controls.Add(this.cmbVechicle);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCollecting_Amount);
            this.Controls.Add(this.txtDelivery_Charge);
            this.Controls.Add(this.lblCollectingAmount);
            this.Controls.Add(this.lblDelivery_Charge);
            this.Controls.Add(this.txtPayment_Type);
            this.Controls.Add(this.lblPayment_Type);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lbDelivered_Date);
            this.Controls.Add(this.lblSendingDate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.dgvCourierParcels);
            this.Controls.Add(this.dtpDeliveredDate);
            this.Controls.Add(this.dtpSendingDate);
            this.Controls.Add(this.txtDeliver_Branch);
            this.Controls.Add(this.lblDeliver_Branch);
            this.Controls.Add(this.txtDeliver_Status);
            this.Controls.Add(this.lblDeliver_Status);
            this.Controls.Add(this.txtWeight);
            this.Controls.Add(this.lblWeight);
            this.Controls.Add(this.txtNo_Of_Items);
            this.Controls.Add(this.lblNo_Of_Items);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Name = "Courier_parcel";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCourierParcels)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblID;
        private Button btnUpdate;
        private Button btnAdd;
        private Label lbDelivered_Date;
        private Label lblSendingDate;
        private Button btnDelete;
        private DataGridView dgvCourierParcels;
        private DataGridViewButtonColumn Column1;
        private DateTimePicker dtpDeliveredDate;
        private DateTimePicker dtpSendingDate;
        private TextBox txtDeliver_Branch;
        private Label lblDeliver_Branch;
        private TextBox txtDeliver_Status;
        private Label lblDeliver_Status;
        private TextBox txtWeight;
        private Label lblWeight;
        private TextBox txtNo_Of_Items;
        private Label lblNo_Of_Items;
        private Label lblPayment_Type;
        private TextBox txtPayment_Type;
        private Label lblCollectingAmount;
        private TextBox txtDelivery_Charge;
        private TextBox txtCollecting_Amount;
        private Label label1;
        private ComboBox cmbVechicle;
        private TextBox txtReceiver;
        private Label lblDelivery_Charge;
        private Label label2;
        private Button btnHome;
        private PictureBox pictureBox2;
    }
}