﻿namespace YienExpressClientApp
{
    partial class Personal_Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Personal_Customer));
            this.dgvPersonalCustomers = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.txtPCity = new System.Windows.Forms.TextBox();
            this.txtPPhone = new System.Windows.Forms.TextBox();
            this.txtPAddress = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblPCity = new System.Windows.Forms.Label();
            this.lblPPhone = new System.Windows.Forms.Label();
            this.lblPAddress = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.txtPProvince = new System.Windows.Forms.TextBox();
            this.lblPProvince = new System.Windows.Forms.Label();
            this.lblPPostal_Code = new System.Windows.Forms.Label();
            this.lblPCountry = new System.Windows.Forms.Label();
            this.txtPPostal_Code = new System.Windows.Forms.TextBox();
            this.txtPCountry = new System.Windows.Forms.TextBox();
            this.txtPEmail = new System.Windows.Forms.TextBox();
            this.lblPEmail = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnHome = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPersonalCustomers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvPersonalCustomers
            // 
            this.dgvPersonalCustomers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPersonalCustomers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1});
            this.dgvPersonalCustomers.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dgvPersonalCustomers.Location = new System.Drawing.Point(405, 118);
            this.dgvPersonalCustomers.Margin = new System.Windows.Forms.Padding(4);
            this.dgvPersonalCustomers.Name = "dgvPersonalCustomers";
            this.dgvPersonalCustomers.RowHeadersWidth = 51;
            this.dgvPersonalCustomers.RowTemplate.Height = 29;
            this.dgvPersonalCustomers.Size = new System.Drawing.Size(691, 440);
            this.dgvPersonalCustomers.TabIndex = 43;
            this.dgvPersonalCustomers.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPersonalCustomers_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Edit";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.Width = 125;
            // 
            // txtPCity
            // 
            this.txtPCity.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtPCity.Location = new System.Drawing.Point(26, 356);
            this.txtPCity.Name = "txtPCity";
            this.txtPCity.Size = new System.Drawing.Size(325, 34);
            this.txtPCity.TabIndex = 42;
            // 
            // txtPPhone
            // 
            this.txtPPhone.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtPPhone.Location = new System.Drawing.Point(25, 610);
            this.txtPPhone.Name = "txtPPhone";
            this.txtPPhone.Size = new System.Drawing.Size(326, 34);
            this.txtPPhone.TabIndex = 41;
            // 
            // txtPAddress
            // 
            this.txtPAddress.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtPAddress.Location = new System.Drawing.Point(24, 284);
            this.txtPAddress.Name = "txtPAddress";
            this.txtPAddress.Size = new System.Drawing.Size(327, 34);
            this.txtPAddress.TabIndex = 40;
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtName.Location = new System.Drawing.Point(30, 118);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(327, 34);
            this.txtName.TabIndex = 39;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Orange;
            this.btnDelete.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnDelete.ForeColor = System.Drawing.Color.DarkRed;
            this.btnDelete.Location = new System.Drawing.Point(904, 595);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(121, 46);
            this.btnDelete.TabIndex = 38;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.Orange;
            this.btnUpdate.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnUpdate.ForeColor = System.Drawing.Color.DarkRed;
            this.btnUpdate.Location = new System.Drawing.Point(707, 595);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(124, 46);
            this.btnUpdate.TabIndex = 37;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Orange;
            this.btnAdd.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnAdd.ForeColor = System.Drawing.Color.DarkRed;
            this.btnAdd.Location = new System.Drawing.Point(494, 595);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(129, 46);
            this.btnAdd.TabIndex = 36;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblPCity
            // 
            this.lblPCity.AutoSize = true;
            this.lblPCity.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPCity.Location = new System.Drawing.Point(26, 318);
            this.lblPCity.Name = "lblPCity";
            this.lblPCity.Size = new System.Drawing.Size(157, 32);
            this.lblPCity.TabIndex = 35;
            this.lblPCity.Text = "City(Nearest)";
            // 
            // lblPPhone
            // 
            this.lblPPhone.AutoSize = true;
            this.lblPPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPPhone.Location = new System.Drawing.Point(30, 584);
            this.lblPPhone.Name = "lblPPhone";
            this.lblPPhone.Size = new System.Drawing.Size(188, 29);
            this.lblPPhone.TabIndex = 34;
            this.lblPPhone.Text = "Phone Number";
            // 
            // lblPAddress
            // 
            this.lblPAddress.AutoSize = true;
            this.lblPAddress.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPAddress.Location = new System.Drawing.Point(24, 244);
            this.lblPAddress.Name = "lblPAddress";
            this.lblPAddress.Size = new System.Drawing.Size(100, 32);
            this.lblPAddress.TabIndex = 33;
            this.lblPAddress.Text = "Address";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblName.Location = new System.Drawing.Point(26, 79);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(124, 32);
            this.lblName.TabIndex = 32;
            this.lblName.Text = "Full Name";
            // 
            // txtPProvince
            // 
            this.txtPProvince.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtPProvince.Location = new System.Drawing.Point(26, 425);
            this.txtPProvince.Name = "txtPProvince";
            this.txtPProvince.Size = new System.Drawing.Size(325, 34);
            this.txtPProvince.TabIndex = 45;
            // 
            // lblPProvince
            // 
            this.lblPProvince.AutoSize = true;
            this.lblPProvince.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPProvince.Location = new System.Drawing.Point(26, 397);
            this.lblPProvince.Name = "lblPProvince";
            this.lblPProvince.Size = new System.Drawing.Size(115, 29);
            this.lblPProvince.TabIndex = 44;
            this.lblPProvince.Text = "Province";
            // 
            // lblPPostal_Code
            // 
            this.lblPPostal_Code.AutoSize = true;
            this.lblPPostal_Code.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPPostal_Code.Location = new System.Drawing.Point(26, 459);
            this.lblPPostal_Code.Name = "lblPPostal_Code";
            this.lblPPostal_Code.Size = new System.Drawing.Size(156, 29);
            this.lblPPostal_Code.TabIndex = 46;
            this.lblPPostal_Code.Text = "Postal Code";
            // 
            // lblPCountry
            // 
            this.lblPCountry.AutoSize = true;
            this.lblPCountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPCountry.Location = new System.Drawing.Point(30, 521);
            this.lblPCountry.Name = "lblPCountry";
            this.lblPCountry.Size = new System.Drawing.Size(102, 29);
            this.lblPCountry.TabIndex = 47;
            this.lblPCountry.Text = "Country";
            // 
            // txtPPostal_Code
            // 
            this.txtPPostal_Code.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtPPostal_Code.Location = new System.Drawing.Point(26, 487);
            this.txtPPostal_Code.Name = "txtPPostal_Code";
            this.txtPPostal_Code.Size = new System.Drawing.Size(325, 34);
            this.txtPPostal_Code.TabIndex = 48;
            // 
            // txtPCountry
            // 
            this.txtPCountry.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtPCountry.Location = new System.Drawing.Point(24, 549);
            this.txtPCountry.Name = "txtPCountry";
            this.txtPCountry.Size = new System.Drawing.Size(327, 34);
            this.txtPCountry.TabIndex = 49;
            this.txtPCountry.TextChanged += new System.EventHandler(this.txtCountry_TextChanged);
            // 
            // txtPEmail
            // 
            this.txtPEmail.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtPEmail.Location = new System.Drawing.Point(24, 199);
            this.txtPEmail.Name = "txtPEmail";
            this.txtPEmail.Size = new System.Drawing.Size(327, 34);
            this.txtPEmail.TabIndex = 50;
            // 
            // lblPEmail
            // 
            this.lblPEmail.AutoSize = true;
            this.lblPEmail.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPEmail.Location = new System.Drawing.Point(26, 162);
            this.lblPEmail.Name = "lblPEmail";
            this.lblPEmail.Size = new System.Drawing.Size(72, 32);
            this.lblPEmail.TabIndex = 51;
            this.lblPEmail.Text = "Email";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblID.Location = new System.Drawing.Point(45, 28);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(0, 32);
            this.lblID.TabIndex = 52;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1126, 187);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(187, 200);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 53;
            this.pictureBox1.TabStop = false;
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.Color.Orange;
            this.btnHome.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnHome.ForeColor = System.Drawing.Color.DarkRed;
            this.btnHome.Location = new System.Drawing.Point(1096, 595);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(121, 46);
            this.btnHome.TabIndex = 54;
            this.btnHome.Text = "Home";
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gold;
            this.ClientSize = new System.Drawing.Size(1325, 653);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.lblPEmail);
            this.Controls.Add(this.txtPEmail);
            this.Controls.Add(this.txtPCountry);
            this.Controls.Add(this.txtPPostal_Code);
            this.Controls.Add(this.lblPCountry);
            this.Controls.Add(this.lblPPostal_Code);
            this.Controls.Add(this.dgvPersonalCustomers);
            this.Controls.Add(this.txtPCity);
            this.Controls.Add(this.txtPPhone);
            this.Controls.Add(this.txtPAddress);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lblPCity);
            this.Controls.Add(this.lblPPhone);
            this.Controls.Add(this.lblPAddress);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtPProvince);
            this.Controls.Add(this.lblPProvince);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPersonalCustomers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView dgvPersonalCustomers;
        private DataGridViewButtonColumn Column1;
        private TextBox txtPCity;
        private TextBox txtPPhone;
        private TextBox txtPAddress;
        private TextBox txtName;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private Label lblPCity;
        private Label lblPPhone;
        private Label lblPAddress;
        private Label lblName;
      

        private TextBox txtPProvince;
        private Label lblPProvince;
        private Label lblPPostal_Code;
        private Label lblPCountry;
        private TextBox txtPPostal_Code;
        private TextBox txtPCountry;
        private TextBox txtPEmail;
        private Label lblPEmail;
        private Label lblID;
        private PictureBox pictureBox1;
        private Button btnHome;
    }
}