﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YienExpressClientApp
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void coparatecustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var coparate_customer = new Coparate_customer();
            
            coparate_customer.Show();
        }

        private void courierparcelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var courierparcel = new Courier_parcel();
            
            courierparcel.Show();
              
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void personalCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var personal_Customer = new Personal_Customer();
            personal_Customer.Show();
           


        }


        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void lblHome_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
