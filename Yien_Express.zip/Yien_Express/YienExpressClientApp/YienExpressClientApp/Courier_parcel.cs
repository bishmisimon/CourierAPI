﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static YienExpressClientApp.Courier_parcel;

namespace YienExpressClientApp
{
    public partial class Courier_parcel : Form
    {
        public Courier_parcel()
        {
            InitializeComponent();
        }


        private void LoadData()
        {
            string uri = "https://localhost:44334/api/Courierparcels\r\n";
            WebClient client = new WebClient();
            client.Headers["Content-type"] = "application/json";
            client.Encoding = Encoding.UTF8;
            string json = client.DownloadString(uri);
            dgvCourierParcels.DataSource = null;
            dgvCourierParcels.DataSource = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Courierparcel>>(json);
            

        }

        public class Courierparcel
        {
            public int ID { get; set; }
            public int No_of_Items { get; set; }
            public string? Weight { get; set; }
            public string? Deliver_Status { get; set; }
            public string? Sending_Date { get; set; }
            public string?ToDeliver_Branch { get; set; }
            public string? Delivered_Date { get; set; }
            public string? Payment_Type { get; set; }
            public decimal Delivery_Charge { get; set; }
            public decimal Collecting_Amount{ get; set; }
            public string? Vechicle_Type { get; set; }

            public string? Receiver_Details { get; set; }
        









    }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtWeight_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            string uri = "https://localhost:44334/api/Courierparcels";
            WebClient client = new WebClient();
            client.Headers["Content-type"] = "application/json";
            client.Encoding = Encoding.UTF8;
            Courierparcel courierparcel = new Courierparcel();
            courierparcel.No_of_Items = Convert.ToInt32(txtNo_Of_Items.Text);

            courierparcel.Weight = txtWeight.Text;

            courierparcel.Deliver_Status = txtDeliver_Status.Text;
            courierparcel.Sending_Date = dtpSendingDate.Value.Date.ToString("o");

            courierparcel.ToDeliver_Branch = txtDeliver_Branch.Text;

            courierparcel.Delivered_Date = dtpDeliveredDate.Value.Date.ToString("o");

            courierparcel.Payment_Type = txtPayment_Type.Text;
            courierparcel.Delivery_Charge = Convert.ToDecimal(txtDelivery_Charge.Text);
            courierparcel.Collecting_Amount = Convert.ToDecimal(txtCollecting_Amount.Text);

            courierparcel.Vechicle_Type=cmbVechicle.Text;
            courierparcel.Receiver_Details = txtReceiver.Text;
            string data = Newtonsoft.Json.JsonConvert.SerializeObject(courierparcel);
            client.UploadString(uri, data);
            LoadData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string uri = "https://localhost:44334/api/Courierparcels/" + lblID.Text;
            HttpClient client = new HttpClient();

            Courierparcel courierparcel = new Courierparcel();
            courierparcel.ID = Convert.ToInt32(lblID.Text);
            courierparcel.No_of_Items = Convert.ToInt32(txtNo_Of_Items.Text);

            courierparcel.Weight = txtWeight.Text;

            courierparcel.Deliver_Status = txtDeliver_Status.Text;
            courierparcel.Sending_Date = dtpSendingDate.Value.Date.ToString("o");

            courierparcel.ToDeliver_Branch = txtDeliver_Branch.Text;

          


            courierparcel.Delivered_Date = dtpDeliveredDate.Value.Date.ToString("o");

            courierparcel.Payment_Type = txtPayment_Type.Text;

            courierparcel.Delivery_Charge = Convert.ToDecimal(txtDelivery_Charge.Text);
            courierparcel.Collecting_Amount = Convert.ToDecimal(txtCollecting_Amount.Text);
            courierparcel.Vechicle_Type=cmbVechicle.Text;
            courierparcel.Receiver_Details = txtReceiver.Text;


            string data = Newtonsoft.Json.JsonConvert.SerializeObject(courierparcel);
            var content = new StringContent(data, UnicodeEncoding.UTF8, "application/json");
            var response = client.PutAsync(uri, content);
            response.Wait();
            var result = response.Result;
            if (result.IsSuccessStatusCode)
                LoadData();
            else
                MessageBox.Show("Failed to Update");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string uri = "https://localhost:44334/api/Courierparcels/" + lblID.Text;
            HttpClient client = new HttpClient();
            var res = client.DeleteAsync(uri);
            res.Wait();
            var result = res.Result;
            if (result.IsSuccessStatusCode)
            {
                LoadData();
            }
            else
                MessageBox.Show("Fail to Delete");
        }

        private void dgvCourierParcels_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            int r = e.RowIndex;
            int c = e.ColumnIndex;
            if (c == 0)
            {
                DataGridViewRow row = dgvCourierParcels.Rows[r];
                lblID.Text = row.Cells[1].Value.ToString();
                txtNo_Of_Items.Text = row.Cells[2].Value.ToString();
                txtWeight.Text = row.Cells[3].Value.ToString();
                txtDeliver_Status.Text = row.Cells[4].Value.ToString();
                dtpSendingDate.Text = row.Cells[5].Value.ToString();
                txtDeliver_Branch.Text = row.Cells[6].Value.ToString();
                dtpDeliveredDate.Text = row.Cells[7].Value.ToString();
                txtPayment_Type.Text = row.Cells[8].Value.ToString();
                txtDelivery_Charge.Text = row.Cells[9].Value.ToString();
                txtCollecting_Amount.Text = row.Cells[10].Value.ToString();
                cmbVechicle.Text = row.Cells[11].Value.ToString();
                txtReceiver.Text = row.Cells[12].Value.ToString();

            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            LoadData();
        }

       


        private void btnHome_Click_1(object sender, EventArgs e)
        {
           

            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
    

}
