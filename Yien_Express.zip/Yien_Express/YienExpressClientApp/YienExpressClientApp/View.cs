﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static YienExpressClientApp.Personal_Customer;

namespace YienExpressClientApp
{
    public partial class View : Form
    {
        private readonly object id;

        public View()
        {
            InitializeComponent();
        }

        private void LoadData()
        {
            string uri = "https://localhost:44334/api/Courierparcels/\r\n"+txtID;
            WebClient client = new WebClient();
            client.Headers["Content-type"] = "application/json";
            client.Encoding = Encoding.UTF8;
            string json = client.DownloadString(uri);
            dgvCourier = null;
            dgvCourier.DataSource=json;
            
        }

        private void View_Load_1(object sender, EventArgs e)
        {
            
        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {
            string uri = "https://localhost:44334/api/Personalcustomers/" + txtID.Text;
            HttpClient client = new HttpClient();

            Courierparcel courierparcel = new Courierparcel();
            courierparcel.ID = Convert.ToInt32(txtID.Text);
            




            var res = client.GetAsync(uri);
            res.Wait();
            var result = res.Result;
            if (result.IsSuccessStatusCode)
            {
                LoadData();
            }
            else
                MessageBox.Show("Fail to View");
        }

        private void dgvCourier_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int r = e.RowIndex;
            int c = e.ColumnIndex;
            if (c == 0)
            {
                DataGridViewRow row = dgvCourier.Rows[r];
                txtID.Text = row.Cells[1].Value.ToString();





            }
        }



    public class Courierparcel
        {
            public int ID { get; set; }
            public int No_of_Items { get; set; }
            public string? Weight { get; set; }
            public string? Deliver_Status { get; set; }

        }



        }
}
























