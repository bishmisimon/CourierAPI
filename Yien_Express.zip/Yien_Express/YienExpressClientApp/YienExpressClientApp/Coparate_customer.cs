using System.Net;
using System.Security.AccessControl;
using System.Text;
using System.Xml.Linq;

namespace YienExpressClientApp
{
    public partial class Coparate_customer : Form
    {
        public Coparate_customer()
        {
            InitializeComponent();
        }


     private void LoadData()

        {
            string uri = "https://localhost:44334/api/Coparatecustomers\r\n";
            WebClient client = new WebClient();
            client.Headers["Content-type"] = "application/json";
            client.Encoding = Encoding.UTF8;
            string json = client.DownloadString(uri);
            dgvCoparateCustomers.DataSource = null;
            dgvCoparateCustomers.DataSource = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Coparatecustomer>>(json);

        }
        public class Coparatecustomer
        {
            public int ID { get; set; }
            public string? Company_Name { get; set; }
            public string? Company_Address { get; set; }
            public string? Phone { get; set; }

            public string? Alternative_Phone { get; set; } 

            public string? Buiness_Email { get; set; }

            public string? Package_Plan { get; set; }


        }



        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvCoparateCustomers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int r = e.RowIndex;
            int c = e.ColumnIndex;
            if (c == 0)
            {
                DataGridViewRow row = dgvCoparateCustomers.Rows[r];
                lblID.Text = row.Cells[1].Value.ToString();
                txtCompany_Name.Text = row.Cells[2].Value.ToString();
                txtCompany_Address.Text = row.Cells[3].Value.ToString();
                txtPhone.Text = row.Cells[4].Value.ToString();
                txtAlternative_Phone.Text= row.Cells[5].Value.ToString();
                txtBuinessEmail.Text= row.Cells[6].Value.ToString();
                cmbPackage.Text = row.Cells[7].Value.ToString();

               



            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string uri = "https://localhost:44334/api/Coparatecustomers/" + lblID.Text;
            HttpClient client = new HttpClient();
            var res = client.DeleteAsync(uri);
            res.Wait();
            var result = res.Result;
            if (result.IsSuccessStatusCode)
            {
                LoadData();
            }
            else
                MessageBox.Show("Fail to Delete");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string uri = "https://localhost:44334/api/Coparatecustomers/" + lblID.Text;
            HttpClient client = new HttpClient();

            Coparatecustomer coparatecustomer = new Coparatecustomer();
            coparatecustomer.ID = Convert.ToInt32(lblID.Text);
            coparatecustomer.Company_Name = txtCompany_Name.Text;
            coparatecustomer.Company_Address = txtCompany_Address.Text;
            coparatecustomer.Phone = txtPhone.Text;
            coparatecustomer.Alternative_Phone= txtAlternative_Phone.Text;
            coparatecustomer.Buiness_Email = txtBuinessEmail.Text;
            coparatecustomer.Package_Plan = cmbPackage.Text;
            

            string data = Newtonsoft.Json.JsonConvert.SerializeObject(coparatecustomer);
            var content = new StringContent(data, UnicodeEncoding.UTF8, "application/json");
            var response = client.PutAsync(uri, content);
            response.Wait();
            var result = response.Result;
            if (result.IsSuccessStatusCode)
                LoadData();
            else
                MessageBox.Show("Failed to Update");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string uri = "https://localhost:44334/api/Coparatecustomers";
            WebClient client = new WebClient();
            client.Headers["Content-type"] = "application/json";
            client.Encoding = Encoding.UTF8;
            Coparatecustomer coparatecustomer = new Coparatecustomer();
            

            coparatecustomer.Company_Name = txtCompany_Name.Text;
            coparatecustomer.Company_Address = txtCompany_Address.Text;
            coparatecustomer.Phone = txtPhone.Text;
            coparatecustomer.Alternative_Phone = txtAlternative_Phone.Text;
            coparatecustomer.Buiness_Email = txtBuinessEmail.Text;
            coparatecustomer.Package_Plan = cmbPackage.Text;


            string data = Newtonsoft.Json.JsonConvert.SerializeObject(coparatecustomer);
            client.UploadString(uri, data);
            LoadData();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
           

            this.Hide();
        }
    }
    
}