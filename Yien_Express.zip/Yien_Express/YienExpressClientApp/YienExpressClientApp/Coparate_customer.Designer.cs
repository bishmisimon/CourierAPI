﻿namespace YienExpressClientApp
{
    partial class Coparate_customer
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Coparate_customer));
            this.lblID = new System.Windows.Forms.Label();
            this.lblCompanyName = new System.Windows.Forms.Label();
            this.lblCompany_Address = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.lblAlternativePhone = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtCompany_Name = new System.Windows.Forms.TextBox();
            this.txtCompany_Address = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.txtAlternative_Phone = new System.Windows.Forms.TextBox();
            this.dgvCoparateCustomers = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.lblBusinessEmail = new System.Windows.Forms.Label();
            this.txtBuinessEmail = new System.Windows.Forms.TextBox();
            this.lblPackage = new System.Windows.Forms.Label();
            this.cmbPackage = new System.Windows.Forms.ComboBox();
            this.btnHome = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCoparateCustomers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(30, 33);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(0, 25);
            this.lblID.TabIndex = 1;
            // 
            // lblCompanyName
            // 
            this.lblCompanyName.AutoSize = true;
            this.lblCompanyName.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCompanyName.Location = new System.Drawing.Point(30, 87);
            this.lblCompanyName.Name = "lblCompanyName";
            this.lblCompanyName.Size = new System.Drawing.Size(172, 30);
            this.lblCompanyName.TabIndex = 2;
            this.lblCompanyName.Text = "Company Name";
            // 
            // lblCompany_Address
            // 
            this.lblCompany_Address.AutoSize = true;
            this.lblCompany_Address.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCompany_Address.Location = new System.Drawing.Point(30, 154);
            this.lblCompany_Address.Name = "lblCompany_Address";
            this.lblCompany_Address.Size = new System.Drawing.Size(92, 30);
            this.lblCompany_Address.TabIndex = 3;
            this.lblCompany_Address.Text = "Address";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPhone.Location = new System.Drawing.Point(30, 223);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(165, 30);
            this.lblPhone.TabIndex = 4;
            this.lblPhone.Text = "Phone Number";
            // 
            // lblAlternativePhone
            // 
            this.lblAlternativePhone.AutoSize = true;
            this.lblAlternativePhone.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblAlternativePhone.Location = new System.Drawing.Point(30, 292);
            this.lblAlternativePhone.Name = "lblAlternativePhone";
            this.lblAlternativePhone.Size = new System.Drawing.Size(193, 30);
            this.lblAlternativePhone.TabIndex = 5;
            this.lblAlternativePhone.Text = "Alternative Phone";
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI Semibold", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnAdd.ForeColor = System.Drawing.Color.DarkRed;
            this.btnAdd.Location = new System.Drawing.Point(516, 497);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(115, 52);
            this.btnAdd.TabIndex = 6;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Font = new System.Drawing.Font("Segoe UI Semibold", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnUpdate.ForeColor = System.Drawing.Color.DarkRed;
            this.btnUpdate.Location = new System.Drawing.Point(649, 497);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(112, 52);
            this.btnUpdate.TabIndex = 7;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI Semibold", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnDelete.ForeColor = System.Drawing.Color.DarkRed;
            this.btnDelete.Location = new System.Drawing.Point(779, 497);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(127, 52);
            this.btnDelete.TabIndex = 8;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtCompany_Name
            // 
            this.txtCompany_Name.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtCompany_Name.Location = new System.Drawing.Point(30, 120);
            this.txtCompany_Name.Name = "txtCompany_Name";
            this.txtCompany_Name.Size = new System.Drawing.Size(250, 37);
            this.txtCompany_Name.TabIndex = 9;
            // 
            // txtCompany_Address
            // 
            this.txtCompany_Address.Location = new System.Drawing.Point(30, 189);
            this.txtCompany_Address.Name = "txtCompany_Address";
            this.txtCompany_Address.Size = new System.Drawing.Size(250, 31);
            this.txtCompany_Address.Font = new System.Drawing.Font("Segoe UI Semibold", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtCompany_Address.TabIndex = 10;
            // 
            // txtPhone
            // 
            this.txtPhone.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtPhone.Location = new System.Drawing.Point(30, 258);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(250, 37);
            this.txtPhone.TabIndex = 11;
            // 
            // txtAlternative_Phone
            // 
            this.txtAlternative_Phone.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtAlternative_Phone.Location = new System.Drawing.Point(30, 329);
            this.txtAlternative_Phone.Name = "txtAlternative_Phone";
            this.txtAlternative_Phone.Size = new System.Drawing.Size(250, 37);
            this.txtAlternative_Phone.TabIndex = 12;
            // 
            // dgvCoparateCustomers
            // 
            this.dgvCoparateCustomers.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dgvCoparateCustomers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCoparateCustomers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1});
            this.dgvCoparateCustomers.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dgvCoparateCustomers.Location = new System.Drawing.Point(316, 87);
            this.dgvCoparateCustomers.Margin = new System.Windows.Forms.Padding(4);
            this.dgvCoparateCustomers.Name = "dgvCoparateCustomers";
            this.dgvCoparateCustomers.RowHeadersWidth = 51;
            this.dgvCoparateCustomers.RowTemplate.Height = 29;
            this.dgvCoparateCustomers.Size = new System.Drawing.Size(609, 372);
            this.dgvCoparateCustomers.TabIndex = 28;
            this.dgvCoparateCustomers.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCoparateCustomers_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Edit";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.Width = 125;
            // 
            // lblBusinessEmail
            // 
            this.lblBusinessEmail.AutoSize = true;
            this.lblBusinessEmail.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblBusinessEmail.Location = new System.Drawing.Point(30, 380);
            this.lblBusinessEmail.Name = "lblBusinessEmail";
            this.lblBusinessEmail.Size = new System.Drawing.Size(156, 30);
            this.lblBusinessEmail.TabIndex = 29;
            this.lblBusinessEmail.Text = "Buisness Email";
            // 
            // txtBuinessEmail
            // 
            this.txtBuinessEmail.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtBuinessEmail.Location = new System.Drawing.Point(30, 422);
            this.txtBuinessEmail.Name = "txtBuinessEmail";
            this.txtBuinessEmail.Size = new System.Drawing.Size(250, 37);
            this.txtBuinessEmail.TabIndex = 30;
            // 
            // lblPackage
            // 
            this.lblPackage.AutoSize = true;
            this.lblPackage.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPackage.Location = new System.Drawing.Point(30, 471);
            this.lblPackage.Name = "lblPackage";
            this.lblPackage.Size = new System.Drawing.Size(219, 30);
            this.lblPackage.TabIndex = 31;
            this.lblPackage.Text = "Special Package Plan";
            // 
            // cmbPackage
            // 
            this.cmbPackage.DisplayMember = "Gold Package(Daily Courier|Rs 100000)";
            this.cmbPackage.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cmbPackage.FormattingEnabled = true;
            this.cmbPackage.Items.AddRange(new object[] {
            "Gold Package(Daily Courier|Rs 100000)",
            "Platinum Package(Weekly Courier|Rs 200000)",
            "Silver Package(Monthly Courier|Rs 50000)"});
            this.cmbPackage.Location = new System.Drawing.Point(30, 511);
            this.cmbPackage.Name = "cmbPackage";
            this.cmbPackage.Size = new System.Drawing.Size(412, 38);
            this.cmbPackage.TabIndex = 32;
            this.cmbPackage.Text = "Gold Package(Daily Courier|Rs 100000)";
            // 
            // btnHome
            // 
            this.btnHome.Font = new System.Drawing.Font("Segoe UI Semibold", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnHome.ForeColor = System.Drawing.Color.DarkRed;
            this.btnHome.Location = new System.Drawing.Point(931, 497);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(127, 52);
            this.btnHome.TabIndex = 33;
            this.btnHome.Text = "Home";
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(941, 154);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(219, 243);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 34;
            this.pictureBox1.TabStop = false;
            // 
            // Coparate_customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Goldenrod;
            this.ClientSize = new System.Drawing.Size(1172, 601);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.cmbPackage);
            this.Controls.Add(this.lblPackage);
            this.Controls.Add(this.txtBuinessEmail);
            this.Controls.Add(this.lblBusinessEmail);
            this.Controls.Add(this.dgvCoparateCustomers);
            this.Controls.Add(this.txtAlternative_Phone);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.txtCompany_Address);
            this.Controls.Add(this.txtCompany_Name);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lblAlternativePhone);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.lblCompany_Address);
            this.Controls.Add(this.lblCompanyName);
            this.Controls.Add(this.lblID);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Coparate_customer";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCoparateCustomers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblID;
        private Label lblCompanyName;
        private Label lblCompany_Address;
        private Label lblPhone;
        private Label lblAlternativePhone;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnDelete;
        private TextBox txtCompany_Name;
        private TextBox txtCompany_Address;
        private TextBox txtPhone;
        private TextBox txtAlternative_Phone;
        private DataGridView dgvCoparateCustomers;
        private DataGridViewButtonColumn Column1;
        private Label lblBusinessEmail;
        private TextBox txtBuinessEmail;
        private Label lblPackage;
        private ComboBox cmbPackage;
        private Button btnHome;
        private PictureBox pictureBox1;
    }
}