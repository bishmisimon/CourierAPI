﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace YienExpressClientApp
{
    public partial class Personal_Customer : Form
    {
        public Personal_Customer()
        {
            InitializeComponent();
        }
        private void LoadData()
        {
            string uri = "https://localhost:44334/api/Personalcustomers\r\n";
            WebClient client = new WebClient();
            client.Headers["Content-type"] = "application/json";
            client.Encoding = Encoding.UTF8;
            string json = client.DownloadString(uri);
            dgvPersonalCustomers.DataSource = null;
            dgvPersonalCustomers.DataSource = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Personalcustomer>>(json);

        }


        public class Personalcustomer
        {
          

            public int ID { get; set; }
            public string? Name { get; set; }

            public string? PEmail { get; set; }
            public string? PAddress { get; set; }
            public string? PCity { get; set; }
            public string? PProvince { get; set; }
            public string? PPostal_Code { get; set; }
            public string? PCountry { get; set; }
            public string? PPhone { get; set; }



        }

        private void txtCountry_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string uri = "https://localhost:44334/api/Personalcustomers";
            WebClient client = new WebClient();
            client.Headers["Content-type"] = "application/json";
            client.Encoding = Encoding.UTF8;
            Personalcustomer personalcustomer = new Personalcustomer();
            personalcustomer.Name = txtName.Text;
            personalcustomer.PAddress = txtPAddress.Text;
            personalcustomer.PEmail = txtPEmail.Text;
            personalcustomer.PCity= txtPCity.Text;
            personalcustomer.PProvince=txtPProvince.Text;
            personalcustomer.PPostal_Code=txtPPostal_Code.Text;
            personalcustomer.PCountry = txtPCountry.Text;
            personalcustomer.PPhone = txtPPhone.Text;
            string data = Newtonsoft.Json.JsonConvert.SerializeObject(personalcustomer);
            client.UploadString(uri, data);
            LoadData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string uri = "https://localhost:44334/api/Personalcustomers/" + lblID.Text;
            HttpClient client = new HttpClient();

            Personalcustomer personalcustomer = new Personalcustomer();
            personalcustomer.ID = Convert.ToInt32(lblID.Text);
            personalcustomer.Name = txtName.Text;
            personalcustomer.PAddress = txtPAddress.Text;
            personalcustomer.PEmail = txtPEmail.Text;
            personalcustomer.PCity = txtPCity.Text;
            personalcustomer.PProvince = txtPProvince.Text;
            personalcustomer.PPostal_Code = txtPPostal_Code.Text;
            personalcustomer.PCountry = txtPCountry.Text;
            personalcustomer.PPhone = txtPPhone.Text;

            string data = Newtonsoft.Json.JsonConvert.SerializeObject(personalcustomer);
            var content = new StringContent(data, UnicodeEncoding.UTF8, "application/json");
            var response = client.PutAsync(uri, content);
            response.Wait();
            var result = response.Result;
            if (result.IsSuccessStatusCode)
                LoadData();
            else
                MessageBox.Show("Failed to Update");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string uri = "https://localhost:44334/api/Personalcustomers/" + lblID.Text;
            HttpClient client = new HttpClient();
            var res = client.DeleteAsync(uri);
            res.Wait();
            var result = res.Result;
            if (result.IsSuccessStatusCode)
            {
                LoadData();
            }
            else
                MessageBox.Show("Fail to Delete");
        }

        private void dgvPersonalCustomers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            int r = e.RowIndex;
            int c = e.ColumnIndex;
            if (c == 0)
            {
                DataGridViewRow row = dgvPersonalCustomers.Rows[r];
                lblID.Text = row.Cells[1].Value.ToString();
                txtName.Text = row.Cells[2].Value.ToString();
                txtPAddress.Text = row.Cells[3].Value.ToString();
                txtPEmail.Text = row.Cells[4].Value.ToString();
                txtPCity.Text = row.Cells[5].Value.ToString();
                txtPProvince.Text = row.Cells[6].Value.ToString();
                txtPPostal_Code.Text = row.Cells[7].Value.ToString();
                txtPCountry.Text = row.Cells[8].Value.ToString();
                txtPPhone.Text = row.Cells[9].Value.ToString();
               

            }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {

            

            this.Hide();
           
            


        }
    }
}
