﻿namespace YienExpressClientApp
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.courierparcelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.coparatecustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.personalCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblHome = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // courierparcelToolStripMenuItem
            // 
            this.courierparcelToolStripMenuItem.Name = "courierparcelToolStripMenuItem";
            this.courierparcelToolStripMenuItem.Size = new System.Drawing.Size(182, 36);
            this.courierparcelToolStripMenuItem.Text = "Courier Parcel";
            this.courierparcelToolStripMenuItem.Click += new System.EventHandler(this.courierparcelToolStripMenuItem_Click);
            // 
            // coparatecustomerToolStripMenuItem
            // 
            this.coparatecustomerToolStripMenuItem.Name = "coparatecustomerToolStripMenuItem";
            this.coparatecustomerToolStripMenuItem.Size = new System.Drawing.Size(242, 36);
            this.coparatecustomerToolStripMenuItem.Text = "Coparate Customer";
            this.coparatecustomerToolStripMenuItem.Click += new System.EventHandler(this.coparatecustomerToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.coparatecustomerToolStripMenuItem,
            this.courierparcelToolStripMenuItem,
            this.personalCustomerToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(820, 40);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // personalCustomerToolStripMenuItem
            // 
            this.personalCustomerToolStripMenuItem.Name = "personalCustomerToolStripMenuItem";
            this.personalCustomerToolStripMenuItem.Size = new System.Drawing.Size(234, 36);
            this.personalCustomerToolStripMenuItem.Text = "Personal Customer";
            this.personalCustomerToolStripMenuItem.Click += new System.EventHandler(this.personalCustomerToolStripMenuItem_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(261, 141);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(278, 285);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // lblHome
            // 
            this.lblHome.AutoSize = true;
            this.lblHome.Font = new System.Drawing.Font("VAGRounded BT", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblHome.Location = new System.Drawing.Point(206, 72);
            this.lblHome.Name = "lblHome";
            this.lblHome.Size = new System.Drawing.Size(387, 44);
            this.lblHome.TabIndex = 5;
            this.lblHome.Text = "Welcome to Home ..!";
            this.lblHome.Click += new System.EventHandler(this.lblHome_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gold;
            this.ClientSize = new System.Drawing.Size(820, 470);
            this.Controls.Add(this.lblHome);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ToolStripMenuItem courierparcelToolStripMenuItem;
        private ToolStripMenuItem coparatecustomerToolStripMenuItem;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem personalCustomerToolStripMenuItem;
        private PictureBox pictureBox2;
        private Label lblHome;
    }
}