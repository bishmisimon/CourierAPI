﻿namespace YienExpressClientApp
{
    partial class View
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtID = new System.Windows.Forms.TextBox();
            this.dgvCourier = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCourier)).BeginInit();
            this.SuspendLayout();
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(121, 166);
            this.txtID.Multiline = true;
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(173, 46);
            this.txtID.TabIndex = 2;
            this.txtID.TextChanged += new System.EventHandler(this.txtID_TextChanged);
            // 
            // dgvCourier
            // 
            this.dgvCourier.AllowUserToAddRows = false;
            this.dgvCourier.AllowUserToDeleteRows = false;
            this.dgvCourier.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvCourier.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCourier.Location = new System.Drawing.Point(361, 81);
            this.dgvCourier.Name = "dgvCourier";
            this.dgvCourier.ReadOnly = true;
            this.dgvCourier.RowHeadersWidth = 62;
            this.dgvCourier.RowTemplate.Height = 33;
            this.dgvCourier.Size = new System.Drawing.Size(360, 225);
            this.dgvCourier.TabIndex = 3;
            this.dgvCourier.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCourier_CellContentClick);
            // 
            // View
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgvCourier);
            this.Controls.Add(this.txtID);
            this.Name = "View";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.View_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCourier)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private TextBox txtID;
        private DataGridView dgvCourier;
    }
}